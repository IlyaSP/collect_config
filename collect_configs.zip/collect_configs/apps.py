from django.apps import AppConfig


class CollectConfigsConfig(AppConfig):
    name = 'collect_configs'
