'''schemy url for collect_configs'''

from django.conf.urls import url
from . import views

urlpatterns = [
    #home page
    url(r'^$', views.index, name = 'index'),
    #Display all device
    url(r'^devices/$', views.devices, name='devices'),
    #Display date added configs for device
    url(r'^devices/(?P<devices_id>\[.*\])/$', views.device, name='device'),
    # obrabotka deystviya knopok
    url(r'^button/(?P<device_id>\d*)-(?P<action>\w*)/$', views.button, name='button'),
    #Display config device added v konkretnyu datu
    url(r'^config/(?P<config_id>\d+)/$', views.config, name='config'),
    # Page edit_device
    url(r'^edit_device/(?P<devices_id>\[.*\]|\d+)/$', views.edit_device, name = 'edit_device'),
    # Add new device
    url(r'^new_device/$', views.new_device, name = 'new_device'),
    # Delete device
    url(r'^delete_device/(?P<devices_id>\[.*\])/$', views.delete_device, name='delete_device'),
    # View logfile
    url(r'^log/$', views.log, name='log'),
    # Refrash device info
    url(r'^refresh_device/(?P<devices_id>\[.*\])/$', views.refresh_device, name='refresh_device'),
    # Configuration collection
    url(r'^config_collect/(?P<devices_id>\[.*\])/$', views.config_collect, name='config_collect'),
    # Delete configuration
    url(r'^delete_config/(?P<config_id>\[.*])/(?P<devices_id>\[.*])/$', views.delete_config, name='delete_config'),
    # View full deviace info
    url(r'^full_device_info/(?P<device_id>\d+)/$', views.full_device_info, name='full_device_info'),
    #Dynamic update of the table with a list of devices
    url(r'^update_table_ajax/$', views.update_table_ajax, name='update_table_ajax'),
    #List of unreachable devices
    url(r'^unreachable_devices/$', views.unreachable_devices, name='unreachable_devices'),
    #export List of unreachable devices
    url(r'^export_unreachable_devices/$', views.export_unreachable_devices, name='export_unreachable_devices'),
    # Configuration collection
    url(r'^export_devices/(?P<devices_id>\[.*\])/$', views.export_devices, name='export_devices'),
    # Configuration comparison page
    url(r'^config_compare_page/(?P<config_id>\[.*])/(?P<devices_id>\[.*])/$', views.config_compare_page, name='config_compare_page'),
    # obrabotka deystviya knopok konfiguracii
    url(r'^button_config/(?P<devices_id>\d+)-(?P<config_id>\d*)-(?P<action>\w*)/$', views.button_config, name='button_config'),
    # page for entering a path to a file with a list of devices
    url(r'^page_add_devices_from_file/$', views.page_add_devices_from_file, name='page_add_devices_from_file'),
    # add device from file
    url(r'^add_devices_from_file/$', views.add_devices_from_file, name='add_devices_from_file'),

]
