# -*- coding: utf-8 -*-
#/usr/bin/python3.5

from django.shortcuts import render
from pysnmp.entity.rfc3413.oneliner import cmdgen

# Create your views here.
from .models import Device, Config, StatisticsDevice
from django.http import HttpResponseRedirect, Http404, HttpResponse
from django.core.urlresolvers import reverse
from .forms import DeviceForm
import socket
import telnetlib
import time
import paramiko
import re
import sqlite3
import datetime
import hashlib
import difflib
from prettytable import PrettyTable
import smbclient
import pexpect
import os


path_to_db = r"/home/admin/collect_config/db.sqlite3"


def write_log(msg):
    with open('logfile.txt', 'a') as f:
        now = datetime.datetime.now()
        date = now.strftime("%d.%m.%Y %I:%M %p")
        f.write(date + msg)


def index(request):
    '''Home page collect_config'''
    return render(request, 'collect_configs/index.html')


def log(request):
    '''Show log file'''
    with open('logfile.txt', 'r') as f:
        log = f.read()
        context = {'log': log}
        return render(request, 'collect_configs/log.html', context)


def add_device(ip, username, password, community):
    print("Start function add_device")
    device_duplicate = Device.objects.filter(ip=ip).values()
    print(device_duplicate)
    if len(device_duplicate) != 0:
        msg = " Device with ip address {0} alredy exists\n".format(ip)
        print(msg)
        write_log(msg)
        result = "FAIL"
    else:
        print('DEVICE notEXIST')
        new_device = Device(ip=ip, username=username, password=password, snmp_community=community)
        print(new_device)
        new_device.save()
        result = "OK"
    return result


def devices(request):
    """display all devices"""
    devices = Device.objects.order_by('ip')
    total_devices = len(devices)
    context = {'devices': devices, 'total_devices': total_devices}
    return render(request, 'collect_configs/devices.html', context)


def update_table_ajax(request):
    if request.is_ajax():
        # print('Start function "update_devices_status"')
        devices = Device.objects.order_by('ip')
        total_devices = len(devices)
        context = {'devices': devices, 'total_devices': total_devices}
        return render(request, 'collect_configs/update_devices_status.html', context)


def device(request, devices_id):
    """Display device and all date configs for him"""
    print('Start function device')
    # print('devices_id = ' + str(devices_id))
    # print('device = ' + str(request.POST))
    device_list = []
    configs_list = []
    for device_id in re.findall(r'\d+', devices_id):
        device = Device.objects.get(id=device_id)
        configs = device.config_set.order_by('-date_added')
        device_list.append(device)
        configs_list.append(configs)
    # print('End work function device')
    print('len list', len(configs_list[0]))
    total_configs = len(configs_list[0])
    context = {'device_list': device_list, 'configs_list': configs_list, 'total_configs': total_configs}
    return render(request, 'collect_configs/device.html', context)


def unreachable_devices(request):
    """display all devices"""
    devices = Device.objects.filter(status = 'Unreachable')
    total_devices = len(devices)
    context = {'devices': devices, 'total_devices': total_devices}
    return render(request, 'collect_configs/unreachable_devices.html', context)


def export_unreachable_devices(request):
    # export List of unreachable devices in file
    print('Start function export_unreachable_devices')
    # print(request.POST.get("format", "0"))

    devices = Device.objects.filter(status='Unreachable')
    format = request.POST.get("format", "0")
    now = datetime.datetime.now()
    date = now.strftime("%d.%m.%Y %I:%M %p").replace(" ",("_"))
    #print(date)
    #print(date.replace(" ",("_")))
    if format == "csv":
        list_device = []
        for device in devices:
            list_device.append("{0};{1};{2};{3};{4}\r\n".format(device.ip, device.hostname, device.model, device.sn,
                                                            device.date_last_change_state))
        print(list_device)
        filename = 'unreachable_devices_{0}.cvs'.format(date)
        with open(filename, 'w') as f:
            for i in sorted(list_device):
                f.write(str(i))
        with open(filename, 'r') as f:
            content = f.read()
        response = HttpResponse(content, content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename = {0}'.format(filename)
        os.remove(filename)
        return response
    else:
        list_device = PrettyTable(["IP", "Hostname", "Model", "Sereal number", "Data last change state"])
        for device in devices:
            list_device.add_row([str(device.ip), device.hostname, device.model, device.sn, device.date_last_change_state])
        list_device.sort_key("IP")
        list_device.reversesort = True
        print(list_device)
        filename = 'unreachable_devices_{0}.txt'.format(date)
        with open(filename, 'w') as f:
            f.write(str(list_device))
        with open(filename, 'r') as f:
            content = f.read()
        response = HttpResponse(content, content_type='text/plain')
        response['Content-Disposition'] = 'attachment; filename = {0}'.format(filename)
        os.remove(filename)
        return response

    #return HttpResponseRedirect(reverse('collect_configs:unreachable_devices'))


def config(request, config_id):
    '''Display config for '''
    config = Config.objects.get(id=config_id)
    context = {'config':config}
    return render(request, 'collect_configs/config.html', context)


def config_compare_page(request, config_id, devices_id):
    '''Configuration comparison page'''
    print('Function config_compare_page')
    print(request.POST)
    configs_id = re.findall(r'\d+', config_id)
    devices_id = re.findall(r'\d+', devices_id)
    print('CONFIG_ID == ', len(configs_id))
    print('DEVICE_ID == ' + str(devices_id))
    if len(configs_id) < 2:
        msg = 'You have selected only one configuration file'
        context = {'msg':msg}
        return render(request, 'collect_configs/config_compare_page.html', context)
    elif len(configs_id) > 2:
        msg = 'You have selected more than two configuration files'
        context = {'msg': msg}
        return render(request, 'collect_configs/config_compare_page.html', context)
    else:
        config_old_id = min(configs_id)
        config_new_id = max(configs_id)
        config_old_s = Config.objects.get(id=config_old_id)
        config_new_s = Config.objects.get(id=config_new_id)
        config_new = config_new_s.config
        config_old = config_old_s.config
        d = difflib.Differ()
        diff1 = d.compare(config_old.split('\n'),config_new.split('\n'))
        # print('\n'.join(diff1))
        diff = '\n'.join(diff1)
        print(diff)
        context = {'config_old': config_old_s, 'config_new': config_new_s, 'diff':diff}
        return render(request, 'collect_configs/config_compare_page.html', context)


def delete_config(request, config_id, devices_id):
    """Delete configuration"""
    print('Function deleteconfig')
    configs_id = re.findall(r'\d+', config_id)
    devices_id = re.findall(r'\d+', devices_id)
    # print('DEVICE_ID == ' + str(devices_id))
    if config_id == None:
        return HttpResponseRedirect(reverse('collect_configs:device', args=[devices_id]))
    else:
        for i in configs_id:
            print('config_id = ' + str(i))
            config = Config.objects.get(id=int(i))
            print(config)
            config.delete()
            msg = ' The configuration from ' + str(config.date_added.strftime("%d.%m.%Y %I:%M %p")) + \
                  ' has been removed\n'
            write_log(msg)
        return HttpResponseRedirect(reverse('collect_configs:device', args=[devices_id]))


def button_config(request, devices_id, config_id, action):
    """Button_config action processing"""
    print('Start button_config function')
    print('button_config = ' + str(request.POST))
    action = request.POST.get('action')
    devices_id = request.POST.getlist('device_id')
    config_id = request.POST.getlist('config_id')
    print('config_id = ' + str(config_id))
    print('devices_id = ' + str(devices_id))
    print('action = ' + str(action))
    print('type-devices_id = ' + str(type(devices_id)))
    if config_id == [] and action == 'delete_config|compare_config':
        print('1-e uslovie')
        return HttpResponseRedirect(reverse('collect_configs:device', args=[devices_id]))
    elif config_id != [] and action == 'delete_config':
        print('2-e uslovie')
        return HttpResponseRedirect(reverse('collect_configs:delete_config', args=(config_id, devices_id)))
    elif action == 'compare_config':
        print('compare')
        return HttpResponseRedirect(reverse('collect_configs:config_compare_page', args=(config_id, devices_id)))


def edit_device(request, devices_id):
    '''Edit device'''
    print('Start function edit device')
    # print(request.POST)
    # device_id = re.findall(r'\d+', devices_id)
    if len(re.findall(r'\d+', devices_id)) > 1:
        msg_err = 'You can edit only one device at a time'
        devices = Device.objects.order_by('ip')
        context = {'devices': devices, 'msg_err': msg_err}
        return render(request, 'collect_configs/devices.html', context)
    else:
        device = Device.objects.get(id = re.findall(r'\d+', devices_id)[0])
        if request.method != 'POST':
             # forma zapolnyaetsy ishodnymi dannymi
            form = DeviceForm(instance = device)
            print(form)
        else:
            # otpravka dannyx POST na obrabotku
            form = DeviceForm(instance = device, data = request.POST)
            print(form)
            print(request.POST)
            #print(device)
            if form.is_valid():
                form.save()
                msg = ' Device: ' + device.ip + ' was edited\n'
                write_log(msg)
                return HttpResponseRedirect(reverse('collect_configs:devices'))
    print(form)
    context = {'device':device, 'form':form}
    return render(request, 'collect_configs/edit_device.html', context)


def new_device(request):
    '''Add new device'''
    print('Function new_device start')
    print('request.POST= ' + str(request.POST))
    if request.method != 'POST':
        '''Create empty form'''
        form = DeviceForm()
    else:
        '''Send data POST'''
        #print('ip device = ' + str(Device.objects.get(ip=request.POST.get('ip'))))
        form = DeviceForm(request.POST)
        device_duplicate = Device.objects.filter(ip = request.POST.get('ip')).values()
        #print(len(device_duplicate))
        if len(device_duplicate) != 0:
            print('DEVICE_EXIST')
            error_device_duplicate = 'ERROR! Device alredy exist'
            context = {'error_device_duplicate': error_device_duplicate}
            return render(request, 'collect_configs/new_device.html', context)
        else:
            print('DEVICE notEXIST')
            if form.is_valid():
                new_device = form.save(commit=False)
                print('new_device = ' + str(request.POST))
                ip = request.POST.get('ip')
                snmp_community = request.POST.get('snmp_community')
                s = get_snmp(ip, snmp_community)
                print(s)
                if s[0].find('No Such Object currently exists at this OID') == -1:
                    new_device.sn = str(s[0])
                else:
                    new_device.sn = 'None'
                print(s[1])
                if s[1].find('No Such Object currently exists at this OID') == -1:
                    if s[1].find('.') == -1:
                        new_device.hostname = s[1]
                    else:
                        new_device.hostname = s[1][:s[1].find('.')]
                else:
                    new_device.hostname = 'None'
                print(s[2])
                if s[2].find('No Such Object currently exists at this OID') == -1:
                    new_device.model = str(s[2])
                else:
                    new_device.model = 'None'
                print(s[3])
                if s[3].find('No Such Object currently exists at this OID') == -1:
                    if re.search(r'\(\w+-\w+-\w+\), Version \d+.\w+\(\w+\)\w*', str(s[3])) != None:
                        new_device.soft_version = re.findall(r'\(\w+-\w+-\w+\), Version \d+.\w+\(\w+\)\w*', str(s[3]))[0]
                    else:
                        new_device.soft_version = s[3]
                    if re.search(r'[Cc]isco|[Ll]inux|[Jj]uniper', s[3]) != None:
                        new_device.vendor_or_OS = re.findall(r'[Cc]isco|[Ll]inux|[Jj]uniper', s[3])[0]
                    else:
                        new_device.vendor_or_OS == 'None'
                else:
                    new_device.soft_version = 'None'
                    new_device.vendor_or_OS == 'None'
                form.save()
                msg = ' Add new device: ' + ip + '\n'
                write_log(msg)
                return HttpResponseRedirect(reverse('collect_configs:devices'))

            else:
                print(form.errors)
                # context = {'form': form.errors}
                # print(context)
                # return render(request, 'collect_configs/new_device.html', context)

    context = {'form': form}
    # print(form)
    return render(request, 'collect_configs/new_device.html', context)


def page_add_devices_from_file(request):
    """Page add devices to database from file"""
    print('Start function page_add_devices_from_file')
    return render(request, 'collect_configs/page_add_devices_from_file.html')


def add_devices_from_file(request):
    '''add devices to database from file'''
    print('Start function add device from file')
    print(request.POST)
    print('path = ' + str(request.POST.get('path_to_file')))
    path_to_file = request.POST.get('path_to_file').split('\\')
    print(path_to_file)
    while '' in path_to_file:
        path_to_file.remove('')
    print(path_to_file)
    server = str(path_to_file[0])
    print('server ip = ' + str(server))
    file_name = '/' + str(path_to_file[len(path_to_file) - 1])
    print('file name = ' + str(file_name))
    path_share = ''
    for i in range(1, len(path_to_file) - 1):
        print(i)
        print(path_to_file[i])
        path_share += str(path_to_file[i]) + '\\\\'
    print('path_share = ' + str(path_share))
    smb1 = smbclient.SambaClient(server=server, share=path_share)
    try:
        f = smb1.open(file_name)
        data = f.readlines()
        print(data)
    except smbclient.SambaClientError as a:
        print(str(a.args))
    k = 0
    amount_device = len(data)
    print("amount devices = ", amount_device)
    for i in data:
        data_list = i.split(";")
        ip = data_list[0]
        username = data_list[1]
        password = data_list[2]
        community = data_list[3]
        result = add_device(ip, username, password, community)
        if result == "OK":
            k += 1
        else:
            continue
    msg = "{0} from {1} Devices added. Errors look in the log file\n".format(k, amount_device)
    context = {'msg': msg}
    return render(request, 'collect_configs/page_add_devices_from_file.html', context)


def delete_device(request, devices_id):
    """Delete device from database"""
    print('Stard delete device')
    for device_id in re.findall(r'\d+', devices_id):
        #print(devices_id)
        device = Device.objects.get(id=device_id)
        print(device)
        device.delete()
        with open('logfile.txt', 'a') as f:
            now = datetime.datetime.now()
            date = now.strftime("%d.%m.%Y %I:%M %p")
            f.write(date + ' Device:' + device.ip + ' was deleted' + '\n')
    return HttpResponseRedirect(reverse('collect_configs:devices'))


def get_snmp(ip, snmp_community):
    '''Get snmp information (hostname, S/N, Chasiss'''
    print('Start function get_snmp')
    cmdGen = cmdgen.CommandGenerator()
    errorIndication, errorStatus, errorIndex, varBinds = cmdGen.getCmd(
        cmdgen.CommunityData(snmp_community),
        cmdgen.UdpTransportTarget((ip, 161)), '1.3.6.1.2.1.47.1.1.1.1.11.1', '1.3.6.1.2.1.1.5.0',
        '1.3.6.1.2.1.47.1.1.1.1.2.1', '.1.3.6.1.2.1.1.1.0'

    )
    print('varBinds = ' + str(varBinds))
    if varBinds == []:
        s = ['None', 'None', 'None', 'None']
        #print(s)

    else:
        s = []
        for i in varBinds:
            # print(i)
            a = str(i)
            s.append(a[a.find('=') + 2:])
    return(s)


def get_snmp_memory(ip, snmp_community, vendor_or_OS):
    '''Get snmp information usage memory'''
    print('Start function get_snmp_memory')
    print("vendor_or_OS = " + str(vendor_or_OS))
    if vendor_or_OS == 'Cisco':
        cmdGen = cmdgen.CommandGenerator()
        errorIndication, errorStatus, errorIndex, varBinds = cmdGen.getCmd(
        cmdgen.CommunityData(snmp_community),
        cmdgen.UdpTransportTarget((ip, 161)), '1.3.6.1.4.1.9.9.48.1.1.1.5.1', '1.3.6.1.4.1.9.9.48.1.1.1.6.1',

        )

        if varBinds == []:
            s = [0, 0]
            #print(s)

        else:
            s = []
            for i in varBinds:
                # print(i)
                a = str(i)
                if a.find('No Such Object currently exists at this OID') == -1:
                    s.append(round(int(a[a.find('=') + 2:])/1024/1024, 2))
                else:s.append('0')



    elif vendor_or_OS == 'Linux':
        cmdGen = cmdgen.CommandGenerator()
        errorIndication, errorStatus, errorIndex, varBinds = cmdGen.getCmd(
            cmdgen.CommunityData(snmp_community),
            cmdgen.UdpTransportTarget((ip, 161)), '1.3.6.1.4.1.2021.4.6.0', '1.3.6.1.4.1.2021.4.13.0',
            '1.3.6.1.4.1.2021.4.14.0', '1.3.6.1.4.1.2021.4.15.0', '1.3.6.1.4.1.2021.4.11.0'

        )
        if varBinds == []:
            s = [0, 0]
            # print(s)

        else:
            s = []
            usage_mem = 0
            for i in range(len(varBinds) - 1):
                a = str(varBinds[i])
                if a.find('No Such Object currently exists at this OID') == -1:
                    print(a)
                    usage_mem += round(int(a[a.find('=') + 2:])/1024, 2)

            s.append(usage_mem)
            free_mem = str(varBinds[-1])
            s.append(round(int(free_mem[free_mem.find('=') + 2:])/1024, 2))

    elif vendor_or_OS == 'Juniper':
        cmdGen = cmdgen.CommandGenerator()
        errorIndication, errorStatus, errorIndex, varBinds = cmdGen.getCmd(
            cmdgen.CommunityData(snmp_community),
            cmdgen.UdpTransportTarget((ip, 161)), '1.3.6.1.4.1.2636.3.1.13.1.11.9.1.0.0', '1.3.6.1.2.1.25.2.2.0',

        )
        if varBinds == []:
            s = [0, 0]
            # print(s)

        else:
            s = []
            for i in varBinds:
                # print(i)
                a = str(i)
                if a.find('No Such Object currently exists at this OID') == -1:
                    s.append(round(int(a[a.find('=') + 2:]) / 1024, 2))
                else:s.append('0')
                # print(s)
    else:
        s = ['None', 'None']

    return(s)


def get_statistics_sql(device_id):
    print('Start function get_statistics_sql')
    con = sqlite3.connect(path_to_db, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    cur = con.cursor()
    date = datetime.datetime.now()
    date1 = date - datetime.timedelta(minutes=10)
    date2 = date - datetime.timedelta(minutes=65)
    # device_id = 60
    # print(device_id)
    # print(date)
    # print(type(date))
    print(date1)

    cur.execute(
        'SELECT cpu_utilization_1min, date_added FROM collect_configs_statisticsdevice WHERE device_id = ? AND  date_added BETWEEN ? AND ? ORDER BY date_added DESC',
        (device_id, date1, date))

    l = cur.fetchall()
    # print(l)
    cpu_stat_10m = []
    for i in range(len(l)):
        cpu_stat_10m.append(int(l[i][0]))

    cur.execute(
        'SELECT cpu_utilization_1min, date_added FROM collect_configs_statisticsdevice WHERE device_id = ? AND  date_added BETWEEN ? AND ? ORDER BY date_added DESC',
        (device_id, date2, date))
    l1 = cur.fetchall()
    # print(l1)
    temp_cpu_stat_60m = []
    for i in l1:
        temp_cpu_stat_60m.append(int(i[0]))

    con.close()
    s = 0
    cpu_stat_60m = []
    # print('len',len(temp_cpu_stat_60m))
    # print(temp_cpu_stat_60m)
    a = 1
    for i in range(len(temp_cpu_stat_60m)):
        if a > 0 and a % 5 == 0:
            # print(s)
            s += temp_cpu_stat_60m[i]
            cpu_stat_60m.append(s / 5)
            s = 0
            a = 1
            # print(i)
            # print('temp_cpu_stat_60m[i] = ' + str(temp_cpu_stat_60m[i]))
            continue
        else:
            # print('i= ',i)
            # print(temp_cpu_stat_60m[i])
            s += temp_cpu_stat_60m[i]
            a += 1
            #print(s)
    # cpu_stat_60m[0] = temp_cpu_stat_60m[0]
    print(cpu_stat_60m)
    return(cpu_stat_10m, cpu_stat_60m)


def refresh_device(request, devices_id):
    """Refrash info device"""
    print('Start function refresh_device')
    #print('refresh_device = ' + str(request.POST))
    #print(request.method)
    for device_id in re.findall(r'\d+', devices_id):
        device = Device.objects.get(id=device_id)
        ip = device.ip
        snmp_community = device.snmp_community
        s = get_snmp(ip, snmp_community)
        #print(s)
        #print(len(s))
        #print(s[0])
        if s[0].find('No Such Object currently exists at this OID') == -1 and s[0].find('None') == -1:
            device.sn = str(s[0])
        else:
            device.sn = 'None'
        #print(s[1])
        if s[1].find('No Such Object currently exists at this OID') == -1 and s[1].find('None') == -1:
            if s[1].find('.') == -1:
                device.hostname = s[1]
            else:
                device.hostname = s[1][:s[1].find('.')]
        else:
            device.hostname = 'None'
        #print(s[2])
        if s[2].find('No Such Object currently exists at this OID') == -1 and s[2].find('None') == -1:
            device.model = str(s[2])
        else:
            device.model = 'None'
        #print('s3== ' + str(s[3]))
        if s[3].find('No Such Object currently exists at this OID') == -1 and s[3].find('None') == -1:
            if re.search(r'\(\w+-\w+-\w+\), Version \d+.\w+\(\w+\)\w*', str(s[3])) != None:
                device.soft_version = re.findall(r'\(\w+-\w+-\w+\), Version \d+.\w+\(\w+\)\w*', str(s[3]))[0]
            else:
                device.soft_version = s[3]
            if re.search(r'[Cc]isco|[Ll]inux|[Jj]uniper', s[3]) != None:
                device.vendor_or_OS = re.findall(r'[Cc]isco|[Ll]inux|[Jj]uniper', s[3])[0]
            else:
                device.vendor_or_OS == 'None'
        else:
            device.vendor_or_OS = 'None'
            device.soft_version = 'None'

        device.save()
    return HttpResponseRedirect(reverse('collect_configs:devices'))


def full_device_info(request, device_id):
    device = Device.objects.get(id=device_id)
    mem_used, mem_free = get_snmp_memory(device.ip, device.snmp_community, device.vendor_or_OS)
    cpu_stat_10m, cpu_stat_60m = get_statistics_sql(device_id)
    context = {'device': device, 'mem_used': mem_used, 'mem_free': mem_free, 'cpu_stat_10m': cpu_stat_10m, 'cpu_stat_60m': cpu_stat_60m}
    return render(request, 'collect_configs/full_device_info.html', context)


def TcpConnect(ip, hostname, vendor, username, password, enable_pass, telnet_port = 23, ssh_port = 22, timeout = 10):
    """Check availability telnet or ssh"""
    session = socket.socket()
    session.settimeout(3)
    result = session.connect_ex((ip, ssh_port))
    session.close()
    print(result)
    if result == 0:
        print('SSH')
        if vendor == "Cisco":
            config, h, msg = SSHConnectCisco(ip=ip, hostname=hostname, user=username,
                                             password=password, enable_pass=enable_pass)
        elif vendor == "Juniper":
            config, h, msg = SSHConnectJuniper(ip=ip, hostname=hostname, user=username,
                                             password=password, enable_pass=enable_pass)
    else:
        session = socket.socket()
        session.settimeout(3)
        result = session.connect_ex((ip, telnet_port))
        session.close()
        print(result)
        if result == 0:
            print('Telnet')
            if vendor == "Cisco":
                config ,h, msg = TelnetConnectCisco(ip=ip, hostname=hostname, user=username,
                                                    password=password, enable_pass=enable_pass)

        else:
            print('Device unreachable')
            config, h = ' ', ' '
            msg = ' Device:' + ip + '  is not available' + '\n'
            #with open('logfile.txt', 'a') as f:
                #now = datetime.datetime.now()
                #date = now.strftime("%d.%m.%Y %I:%M %p")
                #f.write(date + ' Device:' + ip + '  is not available' + '\n')

    return config, h, msg


def TelnetConnectCisco(ip, hostname, user, password, enable_pass):
    '''Connect Connection on port 23. Configuration collection'''
    print("Start function 'TelnetConnectCisco'")
    error_authen = "Permission denied"
    telnet = pexpect.spawn("telnet {0}".format(ip))
    telnet.timeout = 15
    i = telnet.expect([pexpect.TIMEOUT, "[Uu]sername:", pexpect.EOF])
    if i == 0:
        print("TIMEOUT to {0} - {1}".format(ip, hostname))
        config, h = ' ', ' '
    elif i == 1:
        telnet.sendline(user)
        telnet.expect("[Pp]assword:")
        telnet.sendline(password)
    elif i == 2:
        print("EOF Error for {0} - {1}".format(ip, hostname))
        config, h = ' ', ' '

    time.sleep(0.1)
    i = telnet.expect(["#", ">", r"% Login invalid", error_authen])
    if i == 0:
        telnet.sendline("terminal len 0")
        telnet.expect("#")
        # print(ssh.before.decode("utf-8"), ssh.after.decode("utf-8"))
        time.sleep(0.1)
        telnet.sendline("show running-config")
        time.sleep(0.1)
        telnet.expect("#")
        config = telnet.before.decode("utf-8")
        h = hashlib.sha256(config.encode('ascii')).hexdigest()
        msg = "Success show config {0} - {1}".format(ip, hostname)
    elif i == 1:
        telnet.sendline("enable")
        time.sleep(0.1)
        telnet.expect("[Pp]assword:")
        telnet.sendline(enable_pass)
        ii = telnet.expect(["#", "[Pp]assword:"])
        if ii == 0:
            telnet.sendline("terminal len 0")
            telnet.expect("#")
            time.sleep(0.1)
            telnet.sendline("show running-config")
            time.sleep(0.1)
            telnet.expect("#")
            config = telnet.before.decode("utf-8")
            h = hashlib.sha256(config.encode('ascii')).hexdigest()
            msg = "Success show config {0} - {1}".format(ip, hostname)
        else:
            print("Bad enable password for {0} - {1}".format(ip, hostname))
            config, h = ' ', ' '
    elif i == 2:
        print("Bad login or password for {0} - {1}".format(ip, hostname))
        config, h = ' ', ' '
    return config, h, msg


def SSHConnectCisco(ip, hostname, user, password, enable_pass):
    '''Connect Connection on port 22. Configuration collection'''

    print("Connect to {0} - {1}".format(hostname, ip))
    print(ip,  hostname, user, password, enable_pass)
    SSH_NEWKEY = r'Are you sure you want to continue connecting \(yes/no\)\?'
    error_authen = "Permission denied"
    ssh = pexpect.spawn("ssh {0}@{1}".format(user, ip))
    ssh.timeout = 15
    i = ssh.expect([pexpect.TIMEOUT, SSH_NEWKEY, "[Pp]assword:", pexpect.EOF])
    if i == 0:
        msg = "TIMEOUT to {0} - {1}".format(ip, hostname)
        config, h = ' ', ' '
    elif i == 1:
        print("accept key ssh for {0} - {1}".format(ip, hostname))
        ssh.sendline("yes")
        ssh.expect("[Pp]assword:")
        ssh.sendline(password)
    elif i == 2:
        ssh.sendline(password)
    elif i == 3:
        msg = "EOF Error for {0} - {1}".format(ip, hostname)
        config, h = ' ', ' '

    time.sleep(0.1)
    i = ssh.expect(["#", ">", "[Pp]assword:", error_authen])
    if i == 0:
        ssh.sendline("terminal len 0")
        ssh.expect("#")
        time.sleep(0.1)
        ssh.sendline("show running-config")
        time.sleep(0.1)
        ssh.expect("#")
        config = ssh.before.decode("utf-8")
        h = hashlib.sha256(config.encode('ascii')).hexdigest()
        msg = "Success show config {0} - {1}".format(ip, hostname)
    elif i == 1:
        ssh.sendline("enable")
        time.sleep(0.1)
        ssh.expect("[Pp]assword:")
        ssh.sendline(enable_pass)
        ii = ssh.expect(["#", "[Pp]assword:"])
        if ii == 0:
            ssh.sendline("terminal len 0")
            ssh.expect("#")
            time.sleep(0.1)
            ssh.sendline("show running-config")
            time.sleep(0.1)
            ssh.expect("#")
            config = ssh.before.decode("utf-8")
            h = hashlib.sha256(config.encode('ascii')).hexdigest()
            msg = "Success show config {0} - {1}".format(ip, hostname)

        else:
            msg = "Bad enable password for {0} - {1}".format(ip, hostname)
            config, h = ' ', ' '

    elif i == 2:
        msg = "Bad login or password for {0} - {1}".format(ip, hostname)
        config, h = ' ', ' '
    return config, h, msg


def SSHConnectJuniper(ip, hostname, user, password, enable_pass):
    '''Connect Connection on port 22. Configuration collection'''
    # print("Connect to {0} - {1}".format(hostname, ip))
    SSH_NEWKEY = r'Are you sure you want to continue connecting \(yes/no\)\?'
    error_authen = "Permission denied"
    ssh = pexpect.spawn("ssh {0}@{1}".format(user, ip))
    ssh.timeout = 15
    i = ssh.expect([pexpect.TIMEOUT, SSH_NEWKEY, "[Pp]assword:", pexpect.EOF])
    if i == 0:
        print("TIMEOUT to {0} - {1}".format(ip, hostname))
        config, h = ' ', ' '
    elif i == 1:
        print("accept key ssh for {0} - {1}".format(ip, hostname))
        ssh.sendline("yes")
        ssh.expect("[Pp]assword:")
        ssh.sendline(password)
    elif i == 2:
        ssh.sendline(password)
    elif i == 3:
        print("EOF Error for {0} - {1}".format(ip, hostname))
        config, h = ' ', ' '

    time.sleep(1)
    ssh.sendline("\n")
    i = ssh.expect(["%", ">", "[Pp]assword:"])
    if i == 0:
        ssh.sendline("cli")
        ssh.expect(">")
        # print(ssh.before.decode("utf-8"), ssh.after.decode("utf-8"))
        ssh.sendline("set cli screen-length 0")
        time.sleep(0.1)
        ssh.expect(">")
        ssh.sendline("show configuration")
        time.sleep(0.1)
        ssh.expect(">")
        config = ssh.before.decode("utf-8")
        h = hashlib.sha256(config.encode('ascii')).hexdigest()
        msg = "Success show config {0} - {1}".format(ip, hostname)
    elif i == 1:
        ssh.sendline("set cli screen-length 0")
        time.sleep(0.1)
        ssh.expect(">")
        ssh.sendline("show configuration")
        time.sleep(0.1)
        ssh.expect(">")
        config = ssh.before.decode("utf-8")
        h = hashlib.sha256(config.encode('ascii')).hexdigest()
        msg = "Success show config {0} - {1}".format(ip, hostname)
    elif i == 2:
        print("Bad login or password for {0} - {1}".format(ip, hostname))
        config, h = ' ', ' '
    return config, h, msg


def CompareHashConfig(device, h):
    """Compare hash old config and new config"""
    amount_config = len(device.config_set.all())
    print('amount_conf = ' + str(amount_config))
    if amount_config == 0:
        return 0
    else:
        old_hash = device.config_set.order_by('-date_added')[0].hash_config
        print(old_hash)
        if h != old_hash:
            return 0
        else:
            return -1


def config_collect(request, devices_id):
    """Starting the configuration collection"""
    print('Start function config_collect')
    #print('devices_id = ' + str (devices_id))
    #print(type(devices_id))
    msg_err =''
    for device_id in re.findall(r'\d+', devices_id):
        print('device_id = ' + str(device_id))
        device = Device.objects.get(id=device_id)
        ip = device.ip
        username = device.username
        password = device.password
        enable_pass = device.enable_pass
        hostname = device.hostname
        max_number_config = int(device.max_number_cofigs)
        vendor = device.vendor_or_OS
        print("hostnmame = ", hostname)
        config, h, msg = (TcpConnect(ip, hostname, vendor, username, password, enable_pass))
        #print('Config == ' + str(config))
        #print('HASH == ' +str(h))
        #print('MSG == ' + str(msg))
        if h == ' ':
            devices = Device.objects.order_by('ip')
            context = { 'devices': devices, 'msg': msg}
            msg_err += msg + '\n'
            with open('logfile.txt', 'a') as f:
                now = datetime.datetime.now()
                date = now.strftime("%d.%m.%Y %I:%M %p")
                f.write(date + msg)
            #return render(request, 'collect_configs/devices.html', context)
        else:
            res_compare = CompareHashConfig(device, h)
            print(res_compare)
            amount_config = len(device.config_set.all())
            print('amount_conf for device {0} - {1}'.format(hostname, amount_config))
            if amount_config >= max_number_config:
                print("exceed = {0}". format(amount_config - max_number_config))
                for i in range(amount_config - max_number_config):
                    config_id = device.config_set.order_by('date_added')[i].id
                    config = Config.objects.get(id=int(config_id))
                    config.delete()
            if res_compare == 0:
                new_config = Config(config=config, hash_config=h, device_id =device_id)
                new_config.save()
                #return HttpResponseRedirect(reverse('collect_configs:devices'))
            else:
                msg = ' The device ' + ip + ' configuration was not changed \r\n'
                devices = Device.objects.order_by('ip')
                context = {'devices': devices, 'msg': msg}
                with open('logfile.txt', 'a') as f:
                    now = datetime.datetime.now()
                    date = now.strftime("%d.%m.%Y %I:%M %p")
                    f.write(date + msg)
                #return render(request, 'collect_configs/devices.html', context)
    #msg = ' The device ' + ip + ' configuration was not changed \r\n'
    devices = Device.objects.order_by('ip')
    context = {'devices': devices, 'msg': msg}
    return render(request, 'collect_configs/devices.html', context)


def export_devices(request, devices_id):
    """Starting the export_devices"""
    print('Start function export_devices')
    list_device = PrettyTable(["IP", "Hostname", "Model", "Sereal number"])
    for device_id in re.findall(r'\d+', devices_id):
        print('device_id = ' + str(device_id))
        device = Device.objects.get(id=device_id)
        list_device.add_row([device.ip, device.hostname, device.model, device.sn])
    list_device.sort_key('IP')
    print(list_device)
    now = datetime.datetime.now()
    date = now.strftime("%d.%m.%Y %I:%M %p")
    with open('export_device.txt', 'w') as f:
        f.write(str(list_device))

    devices = Device.objects.order_by('ip')
    context = {'devices': devices}
    return render(request, 'collect_configs/devices.html', context)


def button(request, device_id, action):
    """Button action processing"""
    print('Start button function)')
    #print('button = ' + str(request.POST))
    action = request.POST.get('action')
    devices_id = request.POST.getlist('device_id')
    print('devices_id = ' + str(devices_id))
    if devices_id == [] and action != 'add' and action != 'delete':
        return HttpResponseRedirect(reverse('collect_configs:devices'))
    if action == 'view':
        return HttpResponseRedirect(reverse('collect_configs:device', args = [devices_id]))
    elif action == 'edit':
        return HttpResponseRedirect(reverse('collect_configs:edit_device', args=[devices_id]))
    elif action == 'add':
        #print("Redirect to new_device")
        return HttpResponseRedirect(reverse('collect_configs:new_device'))
    elif action == 'delete':
        return HttpResponseRedirect(reverse('collect_configs:delete_device', args=[devices_id]))
    elif action == 'refresh':
        return HttpResponseRedirect(reverse('collect_configs:refresh_device', args=[devices_id]))
    elif action == 'collect_config':
        #print('type devices_id = ' + str(type(devices_id)))
        return HttpResponseRedirect(reverse('collect_configs:config_collect', args=[devices_id]))
    elif action == 'export_devices':
        #print('type devices_id = ' + str(type(devices_id)))
        return HttpResponseRedirect(reverse('collect_configs:export_devices', args=[devices_id]))




