# -*- coding: utf-8 -*-
from django import forms
from .models import Device, Config

class DeviceForm(forms.ModelForm):
    #password = forms.CharField(max_length=32, widget = forms.PasswordInput()) # hidden password for device
    class Meta:
        model = Device
        fields = ['ip', 'hostname', 'model', 'sn', 'username', 'password', 'enable_pass', 'snmp_community', 'vendor_or_OS', 'max_number_cofigs']
        labels = {'text': ''}
        widgets = {'text' : forms.Textarea(attrs = {'cols' : 80})}
