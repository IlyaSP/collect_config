from django.contrib import admin

# Register your models here.
from collect_configs.models import Device, Config
admin.site.register(Device)
admin.site.register(Config)