import os
import sys
import smbclient

#path = "smb://127.0.0.1/test"

#print(os.path.exists(path))
#print(os.path.dirname(path))
#print(os.listdir(path))
#f = open('\\localhost\test\list.txt', 'r')
#smb = smbclient.SambaClient(server="localhost", share="test/test1")
#print(smb)
#print (smb.listdir("/"))
#f = smb.open('/list.txt')
#data = f.read()
#f.close()
#print(data)

path = "\\192.168.19.1\\test\\"
print(path)


smb1 = smbclient.SambaClient(server="192.168.19.1", share="test\\test1")

try:
    f = smb1.listdir("/")
    print(f)
except smbclient.SambaClientError as a:
    print(str(a.args))