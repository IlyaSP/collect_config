from django.db import models

# Create your models here.

class Device(models.Model):
    """Data Device"""
    ip = models.GenericIPAddressField()
    hostname = models.CharField(max_length=300, blank=True)
    model = models.CharField(max_length=300, blank=True)
    sn = models.CharField(max_length=300, blank=True)
    username = models.CharField(max_length=300)
    password = models.CharField(max_length=300, blank=True)
    enable_pass = models.CharField(max_length=300, blank=True)
    snmp_community = models.CharField(max_length=300, blank=True)
    soft_version = models.CharField(max_length=300, blank=True)
    vendor_or_OS = models.CharField(max_length=300, blank=True)
    status = models.CharField(max_length=17, blank=True)
    max_number_cofigs = models.CharField(max_length=4)
    date_last_change_state = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.ip

class Config(models.Model):
    """Device config"""
    device = models.ForeignKey(Device)
    config = models.TextField()
    hash_config = models.TextField()
    date_added = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = 'configs'


class StatisticsDevice(models.Model):
    """Storage device statistics"""
    device = models.ForeignKey(Device)
    cpu_utilization_1min = models.IntegerField()
    cpu_utilization_5min = models.IntegerField()
    date_added = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = 'statistics'


